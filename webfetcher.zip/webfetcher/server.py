from flask import Flask, session, redirect, url_for, request, render_template_string
from flask_session import Session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
import requests
from urllib.parse import urlencode
import json

'''
[kajtek@archlinux webfetcher]$ source venv/bin/activate
(venv) [kajtek@archlinux webfetcher]$ python server.py
'''

# ====== CONFIG ======
app = Flask(__name__)
app.secret_key = "secret"
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

login_manager = LoginManager()
login_manager.init_app(app)

PORT = 3000
STEAM_API_KEY = "34727FF626C8228DBE5FD1050003335E"
RETURN_URL = f"http://localhost:{PORT}/auth/steam/return"
REALM = f"http://localhost:{PORT}/"
OPENID_URL = "https://steamcommunity.com/openid/login"


# ====== USER MODEL ======
class User(UserMixin):
    def __init__(self, steamid, name):
        self.id = steamid
        self.name = name


@login_manager.user_loader
def load_user(user_id):
    name = session.get("display_name")
    return User(user_id, name) if name else None


# ====== ROUTES ======
@app.route("/")
def home():
    if not current_user.is_authenticated:
        return """<h1>Welcome</h1>
                  <a href="/auth/steam">Login with Steam</a>"""
    return redirect("/inventory")


@app.route("/auth/steam")
def auth_steam():
    """Redirect to Steam OpenID for authentication"""
    params = {
        "openid.ns": "http://specs.openid.net/auth/2.0",
        "openid.mode": "checkid_setup",
        "openid.return_to": RETURN_URL,
        "openid.realm": REALM,
        "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
        "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
    }
    return redirect(f"{OPENID_URL}?{urlencode(params)}")


@app.route("/auth/steam/return")
def steam_return():
    """Steam returns here after login"""
    params = request.args.to_dict()
    params["openid.mode"] = "check_authentication"
    response = requests.post(OPENID_URL, data=params)
    if "is_valid:true" not in response.text:
        return redirect("/")

    # Extract SteamID
    steamid = params["openid.claimed_id"].split("/")[-1]

    # Get player summary
    user_data = requests.get("https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/",
                             params={"key": STEAM_API_KEY, "steamids": steamid}).json()
    player = user_data["response"]["players"][0]
    name = player.get("personaname", "Unknown User")

    # Create user session
    user = User(steamid, name)
    login_user(user)
    session["display_name"] = name

    return redirect("/inventory")


@app.route("/logout")
def logout():
    logout_user()
    return redirect("/")


@app.route("/inventory")
@login_required
def inventory():
    steamid = current_user.id
    appid = 730  # CS2
    contextid = 2
    url = f"https://steamcommunity.com/inventory/{steamid}/{appid}/{contextid}"

    try:
        response = requests.get(url)
        data = response.json()

        if not data or "descriptions" not in data:
            return render_template_string("""
                <h1>Could not fetch your inventory.</h1>
                <p>Make sure your inventory is set to <strong>Public</strong>.</p>
                <a href="/">Go Back</a>
            """)

        items = [item.get("market_hash_name", "Unknown Item") for item in data["descriptions"]]

        html = f"""
        <h1>{current_user.name}'s Counter-Strike Items</h1>
        <a href="/logout">Logout</a>
        <ul>{''.join(f"<li>{i}</li>" for i in items)}</ul>
        """
        return html

    except Exception as e:
        print("Error:", e)
        return "Error fetching inventory data."


# ====== START SERVER ======
if __name__ == "__main__":
    app.run(port=PORT, debug=True)
